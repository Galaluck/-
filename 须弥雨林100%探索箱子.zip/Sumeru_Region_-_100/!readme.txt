hi there! This pack was created by zxcreepz#3644 ._.'

i tried to make it legit as possible, so some chests will be divided into parts (c20.1 -> c20.2 etc)

pack based on: https://www.youtube.com/watch?v=9B3cfleOb-4&t=3s&ab_channel=KyoStinV


Before using this pack to make it work properly, you need to complete the aranaras story quest.
(Also check pre-requirements from video above)
After passing - use each category in order (0-9)
Some teleportation points are special and require some action.
Almost all of the points that may not be understood have explanations in the description.

Tagged chests:
[afk] - you can loot it full afk (with enabled auto treasure)
[afk vac] - partically afk - need to kill some mobs (if u turn on mob vacuum and kill aura - afk)


Some chests may not be in the pack, so be sure to turn on the interactive map if you want to collect them all



if you have any additions or anything else - write DMs


gl o_-
